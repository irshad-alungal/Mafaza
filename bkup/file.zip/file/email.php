<?php
    require 'mailer/PHPMailerAutoload.php';
    function sendMail($subject,$body){
        $mail = new PHPMailer;
        $mail->isSMTP();
        $mail->SMTPDebug = 0;
        $mail->Host='mail.fastguardservice.net';
        $mail->Port=465;
        $mail->SMTPAuth=true;
        $mail->SMTPSecure='ssl';
        $mail->Username='webmailer@fastguardservice.net';
        $mail->Password='CLinTMi_iA?G';
        $mail->setFrom('webmailer@fastguardservice.net','Fast Gurad Services Landing Page');
        $mail->addAddress('rod@fastguardservice.com');
        $mail->addAddress('arunchill92@gmail.com');
        $mail->addAddress('nayanamarkspot@gmail.com');
        $mail->isHTML(true);
        $mail->Subject= $subject;
        $mail->Body=$body;
        if($mail->send()){
            return true;
        }
        else{
            return false;
        }
    }

?>

